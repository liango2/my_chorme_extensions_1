var topcontainer = document.createElement("div")
document.body.appendChild(topcontainer)
topcontainer.className = "yanwenzi_topcontainer"
var keytip = document.createElement("div")
topcontainer.appendChild(keytip)
keytip.className = "yanwenzi_keytip"
keytip.innerHTML = "箭头键移动选择，点击ctrl或者command键即可上屏。<a href='http://item.taobao.com/item.htm?spm=0.0.0.0.aNORnL&id=40412199308' style='margin-left:10px;'>赞助我</a><a href='http://itunes.apple.com/cn/app/yan-wen-zi/id866753915?ls=1&mt=8' style='margin-left:10px;'>iphone/ipad版</a>"
var close = document.createElement("a");
topcontainer.appendChild(close)
close.innerHTML = "关闭"
close.className = "yanwenzi_close"
close.onclick = function() {
    topcontainer.style.display = "none"
}
var container = document.createElement("div")
topcontainer.appendChild(container)
container.className = "yanwenzi_container"
container.style.zIndex = "100000000000"
var list;
var activeInput = null;
var activeItem = 0;
var show = function(index) {
    container.innerHTML = "";
    var yans = list[index]
    yans.forEach(function(yan, i) {

        var y = document.createElement("a")
        y.innerHTML = yan
        container.appendChild(y)
        y.className = "yanwenzi_item"
        y.setAttribute("index", index);
        y.setAttribute("yan", yan);
        if (i == 0) {
            y.className = "yanwenzi_item active"
        }
        if (i % 6 == 5) {
            container.innerHTML += "<br/>"
        }
    })
    topcontainer.style.display = "block"
    topcontainer.style.left = this.getBoundingClientRect().left + window.scrollX + "px"
    topcontainer.style.top = this.getBoundingClientRect().top + window.scrollY + this.getBoundingClientRect().height + 10 + "px";
    activeItem = 0;
}
var check = function(e) {

    if (topcontainer.style.display == "block") {
        if (e.keyCode == "37") {
            //zuo
            container.querySelectorAll("a")[activeItem].className = "yanwenzi_item"
            activeItem > 0 && activeItem--
            container.querySelectorAll("a")[activeItem].className = "yanwenzi_item active"
            e.preventDefault()
            return false;
        } else if (e.keyCode == "39") {
            //you
            container.querySelectorAll("a")[activeItem].className = "yanwenzi_item"
            activeItem < (container.querySelectorAll("a").length - 1) && activeItem++
            container.querySelectorAll("a")[activeItem].className = "yanwenzi_item active"
            e.preventDefault()
            return false;
        } else if (e.keyCode == "38") {
            //up
            container.querySelectorAll("a")[activeItem].className = "yanwenzi_item";
            (activeItem - 6) >= 0 && (activeItem -= 6);
            container.querySelectorAll("a")[activeItem].className = "yanwenzi_item active"
            e.preventDefault()
            return false;
        } else if (e.keyCode == "40") {
            //down
            container.querySelectorAll("a")[activeItem].className = "yanwenzi_item";
            ((activeItem + 6) <= (container.querySelectorAll("a").length - 1)) && (activeItem += 6);
            container.querySelectorAll("a")[activeItem].className = "yanwenzi_item active"
            e.preventDefault()
            return false;
        } else if (e.keyCode == "17" || e.keyCode == "91") {
            //go
            target = container.querySelectorAll("a")[activeItem]
            this.value = this.value.substr(0, this.selectionEnd) + target.getAttribute("yan") +
                this.value.substr(this.selectionEnd, this.value.length - 1)
            topcontainer.style.display = "none"
            e.preventDefault()
            return false;
        }
    }



    activeInput = this;
    topcontainer.style.display = "none"
    var text = this.value.substr(0, this.selectionEnd);

    for (var index in list) {
        if (new RegExp(index + "$").test(text)) {
            show.call(this, index)
        }
    }
}
var bind = function(ele) {
    if (ele && !ele.isbind) {

        ele.addEventListener("keyup", check)
        ele.isbind = true;
    }
}
container.onclick = function(e) {
    if (e.target.className.indexOf("yanwenzi_item") != -1) {
        activeInput.value = activeInput.value.substr(0, activeInput.selectionEnd) + e.target.getAttribute("yan") +
            activeInput.value.substr(activeInput.selectionEnd, activeInput.value.length - 1)
        topcontainer.style.display = "none"
    }
}



var myport = chrome.extension.connect();
myport.onDisconnect.addListener(function(event) {
    // Happened immediately before adding the proper backend setup.
    // With proper backend setup, allows to determine the extension being disabled or unloaded.
});
myport.postMessage({
    cmd: "yans"
});

myport.onMessage.addListener(function(response) {
    list = response;

    setInterval(function() {
        var areas = document.querySelectorAll("textarea")
        var inputs = document.querySelectorAll("input[type='text']")

        for (var i = 0; i < inputs.length; i++) {
            bind(inputs[i])
        }
        for (var i = 0; i < areas.length; i++) {
            bind(areas[i])
        }
    }, 500)

});