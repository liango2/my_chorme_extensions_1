﻿chrome.extension.sendRequest({ type: 'popup' });
window.close();