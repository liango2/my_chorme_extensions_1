var webster_url = "https://halo.xhacker.im/webster/query/";
var youdao_url = "https://halo.xhacker.im/youdao/query/";
