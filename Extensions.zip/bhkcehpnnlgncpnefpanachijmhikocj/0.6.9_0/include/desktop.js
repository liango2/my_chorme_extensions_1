var is_node_webkit = (typeof process == "object")
if (is_node_webkit) {
    document.write('<link rel="stylesheet" type="text/css" href="style/desktop.css" />')
}
