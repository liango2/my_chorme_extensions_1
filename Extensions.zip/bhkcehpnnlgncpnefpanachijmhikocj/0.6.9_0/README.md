Halo Word Dictionary
========

![Promo Image](http://ww1.sinaimg.cn/large/70cecf67jw1e900jtcothj212w0fkq7f.jpg)

A well-designed English ⇒ Chinese dictionary for Chrome. [Download from Chrome Web Store](https://chrome.google.com/webstore/detail/halo-word-dictionary/bhkcehpnnlgncpnefpanachijmhikocj)

Halo Word is open-sourced under MIT license, pull requests are welcome!

## Icon
The icons of this project are from Oxygen Project and are under LGPL license.
